chrome.contextMenus.create({"title": "Post Image To Tumblr", "contexts":["image"], "onclick": postImage});

function postImage(info, tab) 
{
	var email = localStorage["tumblr_email"];
	var password = localStorage["tumblr_pass"];
	var publishState = localStorage["publish_state"];
	var preformatPost = localStorage["preformat_post"];
	
	if(!email || email=="" || !password || password=="")
	{
		// Whoops!
		alert("You need to set your Tumblr username and password in the options before posting!");
		
		// Go to the options page
		chrome.tabs.create({url:"options.html"});	
	}
	else if(preformatPost==1)
	{
		chrome.tabs.create({url:"share.html?u="+encodeURIComponent(info.srcUrl)});
	}
	else
	{		
		var o = 
		{
			"email":email,
			"password":password,
			"type":"photo",
			"source":info.srcUrl,
			"state":publishState
		};
		
		var postingNote = webkitNotifications.createNotification('images/icon48.png', "Posting Image..", info.srcUrl);
		postingNote.show();
		
		$.ajax({
		  url: 'http://www.tumblr.com/api/write',
		  type: 'POST',
		  data:o,
		  async: false,
		  complete: function(transport)
		  {		 
				if(transport.status == 200 || transport.status == 201) 
				{
					 postingNote.cancel();				 
					 var postedNote = webkitNotifications.createNotification('images/icon48.png', "Image Posted!", info.srcUrl);					 
					 setTimeout(function() { postedNote.cancel(); }, 5000);
					 postedNote.show();
				} 
				else if(transport.status == 403) 
				{
					postingNote.cancel();				 
					var errorNote = webkitNotifications.createNotification('images/icon48.png', "Posting Error!", "Bad email or password");
					setTimeout(function() { errorNote.cancel(); }, 5000);
					errorNote.show();					
					
					// Go to the options page
					chrome.tabs.create({url:"options.html"});
				}
		
			}
		 });		
	}
}