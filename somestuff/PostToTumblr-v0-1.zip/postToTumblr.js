chrome.contextMenus.create({"title": "Post Image To Tumblr", "contexts":["image"], "onclick": postImage});

function postImage(info, tab) 
{
	var email = localStorage["tumblr_email"];
	var password = localStorage["tumblr_pass"];
	
	if(!email || email=="" || !password || password=="")
	{
		alert("Need to set your Tumblr username and password in the options before posting!");
	}
	else
	{	
		var o = 
		{
			"email":email,
			"password":password,
			"type":"photo",
			"source":info.srcUrl	
		};
		
		var success = function(data,textStatus,request)
		{
			if(textStatus=="success"){ alert("Image posted to Tumblr. Image -> "+info.srcUrl); }
			else { alert("Bad email or password"); }
		}
		
		$.post("http://www.tumblr.com/api/write",o, success);	
	}
}