updateContext();

function postImage(info, tab, blog) 
{	
	var tweetPost = localStorage["tweet_post"];
	var email = localStorage["tumblr_email"];
	var password = localStorage["tumblr_pass"];
	var publishState = localStorage["publish_state"];	
	var preformatPost = localStorage["preformat_post"];
	
	if(!email || email=="" || !password || password=="")
	{
		// Whoops!
		alert("You need to set your Tumblr username and password in the options before posting!");
		
		// Go to the options page
		chrome.tabs.create({url:"options.html"});	
	}
	else if(preformatPost==1)
	{
		chrome.tabs.create({url:"share.html?u="+encodeURIComponent(info.srcUrl)});
	}
	else
	{			
		var sendToTwitter = tweetPost;		
		if(tweetPost=="prompt"){ sendToTwitter=confirm("Post to Twitter?")?"auto":"no"; }
				
		var o = 
		{
			"email":email,
			"password":password,
			"type":"photo",
			"source":info.srcUrl,
			"state":publishState,
			"send-to-twitter":sendToTwitter
		};
		
		// Handle multiple blogs
		if(blog!="Default Blog"){o.group = blog;}
		
		var postingNote = webkitNotifications.createNotification('images/icon48.png', "Posting Image..", info.srcUrl);
		postingNote.show();				
	
		$.ajax({
		  url: 'http://www.tumblr.com/api/write',
		  type: 'POST',
		  data:o,
		  async: false,
		  complete: function(transport)
		  {		 
				if(transport.status == 200 || transport.status == 201) 
				{
					 postingNote.cancel();				 
					 var postedNote = webkitNotifications.createNotification('images/icon48.png', "Image Posted!", info.srcUrl);					 
					 setTimeout(function() { postedNote.cancel(); }, 5000);
					 postedNote.show();
				} 
				else if(transport.status == 403) 
				{
					postingNote.cancel();				 
					var errorNote = webkitNotifications.createNotification('images/icon48.png', "Posting Error!", "Bad email or password");
					setTimeout(function() { errorNote.cancel(); }, 5000);
					errorNote.show();					
					
					// Go to the options page
					chrome.tabs.create({url:"options.html"});
				}
		
			}
		 });			
	}
}

function updateContext()
{
	chrome.contextMenus.removeAll();
	
	var additionalBlogsStr = localStorage["additional-blogs-txt"];
	if(!additionalBlogsStr || additionalBlogsStr=="")
	{
		chrome.contextMenus.create({"title": "Post Image To Tumblr", "contexts":["image"], "onclick": function(info, tab){postImage(info,tab,"Default Blog")} });
	}
	else
	{
		var blogs = additionalBlogsStr.split(",");
		for (var i in blogs) { blogs[i] = $.trim(blogs[i]);	 }
		blogs.unshift("Default Blog");
		
		var primaryMenu = chrome.contextMenus.create({"title": "Post Image To Tumblr Blog..", "contexts":["image"]});	
		$(blogs).each(function()
		{		
			var b = this+"";	
			chrome.contextMenus.create({"title": b, "parentId":primaryMenu, "contexts":["image"], "onclick": function(info, tab){postImage(info,tab,b)}});
		});	
	}
}